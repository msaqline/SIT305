package com.example.unitconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {


    Integer SpinnerValue;
    EditText input;
    TextView output1;
    TextView output2;
    TextView output3;
    TextView measurement1;
    TextView measurement2;
    TextView measurement3;
    ImageButton weight;
    ImageButton temperature;
    ImageButton ruler;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.textView7);

        output1 = findViewById(R.id.textView8);
        output2 = findViewById(R.id.textView10);
        output3 = findViewById(R.id.textView12);
        measurement1 = findViewById(R.id.textView9);
        measurement2 = findViewById(R.id.textView11);
        measurement3 = findViewById(R.id.textView13);
        weight = findViewById(R.id.imageButton);
        temperature = findViewById(R.id.imageButton2);
        ruler = findViewById(R.id.imageButton3);

        android.widget.Spinner spinner = findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.units_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);



    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String option = parent.getItemAtPosition(position).toString();
        if(option.toString().equals("meter")){
            SelectMeter(parent);

        }
        if(option.toString().equals("Celsius")){
            SelectCelsius(parent);

        }
        if(option.toString().equals("Kilos")){
            SelectKilos(parent);

        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent){}

    public void SelectMeter(AdapterView<?> parent) {
        SpinnerValue = 1;
        output1.setText("");
        output2.setText("");
        output3.setText("");
        measurement1.setText("Centimeter");
        measurement2.setText("Foot");
        measurement3.setText("Inches");
    }
    public void SelectCelsius(AdapterView<?> parent) {
        SpinnerValue=2;
        output1.setText("");
        output2.setText("");
        output3.setText("");
        measurement1.setText("Fahrenheit");
        measurement2.setText("Kelvin");
        measurement3.setText("");
        
    }
    public void SelectKilos(AdapterView<?> parent){
        SpinnerValue=3;
        output1.setText("");
        output2.setText("");
        output3.setText("");
        measurement1.setText("Gram");
        measurement2.setText("Oz");
        measurement3.setText("Pounds");
    }
    public void ConvertMeters(View view){
        if (SpinnerValue != 1){
            Toast.makeText(this,"please select correct conversion", Toast.LENGTH_LONG).show();
            return;
        }
        double inputNumber=0;
        try{
            String stringInput = input.getText().toString();
            inputNumber = Double.parseDouble(stringInput);
        }
        catch(Exception e){
            Toast.makeText(this,"please select correct conversion", Toast.LENGTH_LONG).show();
        }
        double Output1 = (inputNumber*100);
        double Output2 = (inputNumber*3.2808);
        double Output3 = (inputNumber*39.370);

        DecimalFormat dec = new DecimalFormat("#.##");
        output1.setText(dec.format(Output1));
        output2.setText(dec.format(Output2));
        output3.setText(dec.format(Output3));
        
    }
    public void ConvertCelsius(View view){
        if (SpinnerValue != 2){
            Toast.makeText(this,"please select correct conversion", Toast.LENGTH_LONG).show();
            return;
        }
        double inputNumber=0;
        try{
            String stringInput = input.getText().toString();
            inputNumber = Double.parseDouble(stringInput);
        }
        catch(Exception e){
            Toast.makeText(this,"please select correct conversion", Toast.LENGTH_LONG).show();
        }
        double Output1 = (inputNumber*(9/5)+32);
        double Output2 = (inputNumber+273.15);


        DecimalFormat dec = new DecimalFormat("#.##");
        output1.setText(dec.format(Output1));
        output2.setText(dec.format(Output2));
        output3.setText("");

    }
    public void ConvertKilos(View view){
        if (SpinnerValue != 3){
            Toast.makeText(this,"please select correct conversion", Toast.LENGTH_LONG).show();
            return;
        }
        double inputNumber=0;
        try{
            String stringInput = input.getText().toString();
            inputNumber = Double.parseDouble(stringInput);
        }
        catch(Exception e){
            Toast.makeText(this,"please select correct conversion", Toast.LENGTH_LONG).show();
        }
        double Output1 = (inputNumber*1000);
        double Output2 = (inputNumber*35.27);
        double Output3 = (inputNumber*2.20);

        DecimalFormat dec = new DecimalFormat("#.##");
        output1.setText(dec.format(Output1));
        output2.setText(dec.format(Output2));
        output3.setText(dec.format(Output3));

    }

    
}